<?php
$servidor = "localhost";
$usuario_bd = "root";
$contrasena_bd = "";
$base_datos = "hospital_clinicas";

$conexion = mysqli_connect(
    $servidor,
    $usuario_bd,
    $contrasena_bd,
    $base_datos
);

if (!$conexion) {
    die("Error al conectar con la base de datos: " . mysqli_connect_error());
}

mysqli_set_charset($conexion, "utf8mb4");
?>
