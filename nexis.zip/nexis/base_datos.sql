-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2026 at 02:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_clinicas`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambulancias`
--

CREATE TABLE `ambulancias` (
  `id_ambulancia` int(11) NOT NULL,
  `identificador` varchar(50) NOT NULL,
  `matricula` varchar(20) NOT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ambulancias`
--

INSERT INTO `ambulancias` (`id_ambulancia`, `identificador`, `matricula`, `estado`) VALUES
(1, 'Ambulancia 01', 'ABC123', 'en traslado'),
(2, 'Ambulancia 02', 'ABC124', 'en traslado');

-- --------------------------------------------------------

--
-- Table structure for table `documentos`
--

CREATE TABLE `documentos` (
  `id_documento` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `archivo` varchar(255) NOT NULL,
  `fecha_subida` datetime NOT NULL DEFAULT current_timestamp(),
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documentos`
--

INSERT INTO `documentos` (`id_documento`, `titulo`, `descripcion`, `archivo`, `fecha_subida`, `id_usuario`) VALUES
(2, 'Prueba 1', 'ensayo de prueba', '1788122776_Tutor__a_UTULAB_Nexis_3__MK.pdf', '2026-08-30 17:46:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `encuestas`
--

CREATE TABLE `encuestas` (
  `id_encuesta` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'activa',
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `encuestas`
--

INSERT INTO `encuestas` (`id_encuesta`, `titulo`, `descripcion`, `estado`, `fecha_creacion`, `id_usuario`) VALUES
(1, 'Encuesta de satisfacción', 'Encuesta para conocer la opinión de los pacientes.', 'activa', '2026-08-30 00:13:36', 1),
(2, 'prueba 1', '', 'activa', '2026-08-30 00:34:00', 1),
(3, 'prueba 3', 'como estuvo la doctora?', 'activa', '2026-08-30 19:25:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `preguntas`
--

CREATE TABLE `preguntas` (
  `id_pregunta` int(11) NOT NULL,
  `id_encuesta` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `tipo` varchar(30) NOT NULL DEFAULT 'opcion',
  `orden` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `preguntas`
--

INSERT INTO `preguntas` (`id_pregunta`, `id_encuesta`, `pregunta`, `tipo`, `orden`) VALUES
(1, 1, '¿Qué tan satisfecho está con la atención recibida?', 'opcion', 1),
(2, 2, 'Estuvo limpio el hospital en su Instancia?', 'opcion', 1),
(3, 3, 'La doctora estaba Linda?', 'opcion', 1);

-- --------------------------------------------------------

--
-- Table structure for table `respuestas`
--

CREATE TABLE `respuestas` (
  `id_respuesta` int(11) NOT NULL,
  `id_respuesta_encuesta` int(11) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `respuesta` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `respuestas`
--

INSERT INTO `respuestas` (`id_respuesta`, `id_respuesta_encuesta`, `id_pregunta`, `respuesta`) VALUES
(1, 1, 2, 'Satisfecho'),
(2, 2, 2, 'Regular'),
(3, 3, 2, 'Regular'),
(4, 4, 2, 'Muy insatisfecho'),
(5, 5, 2, 'Regular'),
(6, 6, 2, 'Muy satisfecho'),
(7, 7, 2, 'Muy satisfecho');

-- --------------------------------------------------------

--
-- Table structure for table `respuestas_encuesta`
--

CREATE TABLE `respuestas_encuesta` (
  `id_respuesta_encuesta` int(11) NOT NULL,
  `id_encuesta` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `respuestas_encuesta`
--

INSERT INTO `respuestas_encuesta` (`id_respuesta_encuesta`, `id_encuesta`, `fecha`) VALUES
(1, 2, '2026-08-30 00:34:06'),
(2, 2, '2026-08-30 00:34:17'),
(3, 2, '2026-08-30 19:26:27'),
(4, 2, '2026-08-30 19:26:46'),
(5, 2, '2026-08-30 19:26:51'),
(6, 2, '2026-08-30 19:27:01'),
(7, 2, '2026-08-30 19:27:06');

-- --------------------------------------------------------

--
-- Table structure for table `traslados`
--

CREATE TABLE `traslados` (
  `id_traslado` int(11) NOT NULL,
  `id_ambulancia` int(11) NOT NULL,
  `paciente` int(10) NOT NULL,
  `conductor` varchar(100) NOT NULL,
  `enfermero` mediumint(100) DEFAULT NULL,
  `origen` varchar(150) NOT NULL,
  `destino` varchar(150) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `traslados`
--

INSERT INTO `traslados` (`id_traslado`, `id_ambulancia`, `paciente`, `conductor`, `enfermero`, `origen`, `destino`, `fecha`, `hora`, `estado`) VALUES
(1, 1, 0, 'Gonzalo', 0, 'Hospital de Clinicas', 'Brazo Oriental', '2026-09-06', '02:36:00', 'en curso'),
(2, 1, 0, 'Gonzalo', 0, 'Hospital de Clinicas', 'Brazo Oriental', '2026-09-06', '03:38:00', 'finalizado'),
(3, 2, 0, 'wqd', 0, 'qwdwqd', 'wd', '2026-08-01', '23:23:00', 'finalizado'),
(4, 2, 0, 'wqd', 0, 'qwdwqd', 'wd', '2026-08-01', '23:23:00', 'finalizado'),
(5, 2, 57831971, 'Gonzalo Duarte', 8388607, 'La casa de Santiago Garcia', 'Hospital de Clinicas', '2026-09-02', '01:32:00', 'en curso');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'funcionario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `contraseña`, `nombre`, `correo`, `rol`) VALUES
(1, 'admin', '$2y$12$gGNR3WcFhsbn7hcGySOIzePSEb2SFQn6RZNyZ9loyFSnFIuNv/6Wq', 'Administrador', 'nexiserg0@gmail.com', 'administrador'),
(2, 'santiago', '$2y$10$Qr/xFUThdpB7kXutNDP84eowhuV1zRFvZeesVa1VVal4KNYFD0pJO', 'Santiago Garcia', 'sg9509732@gmail.com', 'funcionario');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambulancias`
--
ALTER TABLE `ambulancias`
  ADD PRIMARY KEY (`id_ambulancia`);

--
-- Indexes for table `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id_documento`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indexes for table `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`id_encuesta`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indexes for table `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id_pregunta`),
  ADD KEY `id_encuesta` (`id_encuesta`);

--
-- Indexes for table `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id_respuesta`),
  ADD KEY `id_respuesta_encuesta` (`id_respuesta_encuesta`),
  ADD KEY `id_pregunta` (`id_pregunta`);

--
-- Indexes for table `respuestas_encuesta`
--
ALTER TABLE `respuestas_encuesta`
  ADD PRIMARY KEY (`id_respuesta_encuesta`),
  ADD KEY `id_encuesta` (`id_encuesta`);

--
-- Indexes for table `traslados`
--
ALTER TABLE `traslados`
  ADD PRIMARY KEY (`id_traslado`),
  ADD KEY `id_ambulancia` (`id_ambulancia`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ambulancias`
--
ALTER TABLE `ambulancias`
  MODIFY `id_ambulancia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `documentos`
--
ALTER TABLE `documentos`
  MODIFY `id_documento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `encuestas`
--
ALTER TABLE `encuestas`
  MODIFY `id_encuesta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id_pregunta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `id_respuesta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `respuestas_encuesta`
--
ALTER TABLE `respuestas_encuesta`
  MODIFY `id_respuesta_encuesta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `traslados`
--
ALTER TABLE `traslados`
  MODIFY `id_traslado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `documentos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Constraints for table `encuestas`
--
ALTER TABLE `encuestas`
  ADD CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Constraints for table `preguntas`
--
ALTER TABLE `preguntas`
  ADD CONSTRAINT `preguntas_ibfk_1` FOREIGN KEY (`id_encuesta`) REFERENCES `encuestas` (`id_encuesta`) ON DELETE CASCADE;

--
-- Constraints for table `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`id_respuesta_encuesta`) REFERENCES `respuestas_encuesta` (`id_respuesta_encuesta`) ON DELETE CASCADE,
  ADD CONSTRAINT `respuestas_ibfk_2` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`) ON DELETE CASCADE;

--
-- Constraints for table `respuestas_encuesta`
--
ALTER TABLE `respuestas_encuesta`
  ADD CONSTRAINT `respuestas_encuesta_ibfk_1` FOREIGN KEY (`id_encuesta`) REFERENCES `encuestas` (`id_encuesta`) ON DELETE CASCADE;

--
-- Constraints for table `traslados`
--
ALTER TABLE `traslados`
  ADD CONSTRAINT `traslados_ibfk_1` FOREIGN KEY (`id_ambulancia`) REFERENCES `ambulancias` (`id_ambulancia`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
