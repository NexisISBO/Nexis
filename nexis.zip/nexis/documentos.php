<?php
include 'proteger.php';
include 'conexion.php';

$mensaje = $error = '';
$carpeta = 'documentos';
if (!is_dir($carpeta)) mkdir($carpeta, 0777, true);

if (isset($_GET['eliminar'])) {
    $id = (int) $_GET['eliminar'];
    $r = mysqli_query($conexion, "SELECT archivo FROM documentos WHERE id_documento=$id");
    $d = mysqli_fetch_assoc($r);

    if ($d) {
        if (file_exists("$carpeta/{$d['archivo']}")) unlink("$carpeta/{$d['archivo']}");
        mysqli_query($conexion, "DELETE FROM documentos WHERE id_documento=$id");
    }

    header('Location: documentos.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = mysqli_real_escape_string($conexion, trim($_POST['titulo']));
    $desc = mysqli_real_escape_string($conexion, trim($_POST['descripcion']));

    if (!$titulo || !isset($_FILES['archivo']) || $_FILES['archivo']['error'] != 0) {
        $error = 'Complete el título y seleccione un archivo.';
    } else {
        $nombre = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['archivo']['name']));
        $destino = "$carpeta/$nombre";

        if (move_uploaded_file($_FILES['archivo']['tmp_name'], $destino)) {
            $uid = (int) $_SESSION['id_usuario'];
            $sql = "INSERT INTO documentos(titulo,descripcion,archivo,id_usuario)
                    VALUES('$titulo','$desc','$nombre',$uid)";

            if (mysqli_query($conexion, $sql)) $mensaje = 'Documento subido correctamente.';
            else { unlink($destino); $error = 'No se pudo guardar el documento.'; }
        } else $error = 'No se pudo guardar el archivo.';
    }
}

$documentos = mysqli_query($conexion,
    'SELECT d.*,u.usuario FROM documentos d LEFT JOIN usuarios u
     ON u.id_usuario=d.id_usuario ORDER BY d.id_documento DESC');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos - Hospital de Clínicas</title>
    <link rel="stylesheet" href="documentos.css">
</head>
<body>
<header>
    <a href="inicio.php">← Volver</a>
    <h1>Documentos</h1>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main>
    <h2>Gestión de documentos</h2>

    <?php if ($mensaje): ?><p class="mensaje correcto"><?= htmlspecialchars($mensaje) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="mensaje error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <section class="tarjeta">
        <h3>Subir documento</h3>
        <form method="POST" enctype="multipart/form-data">
            <label>Título</label>
            <input name="titulo" required>
            <label>Descripción</label>
            <textarea name="descripcion"></textarea>
            <label>Archivo</label>
            <input type="file" name="archivo" required>
            <button>Subir documento</button>
        </form>
    </section>

    <section>
        <h3>Documentos registrados</h3>
        <?php if (mysqli_num_rows($documentos) == 0): ?>
            <div class="tarjeta vacio">No hay documentos registrados.</div>
        <?php endif; ?>

        <?php while ($d = mysqli_fetch_assoc($documentos)): ?>
            <article class="archivo">
                <div>
                    <h4><?= htmlspecialchars($d['titulo']) ?></h4>
                    <p><?= htmlspecialchars($d['descripcion']) ?></p>
                    <small>Subido por: <?= htmlspecialchars($d['usuario'] ?? 'Usuario') ?></small>
                </div>
                <div class="acciones">
                    <a href="documentos/<?= rawurlencode($d['archivo']) ?>" target="_blank">Ver</a>
                    <a href="editar_documento.php?id=<?= $d['id_documento'] ?>">Editar</a>
                    <a class="eliminar" href="documentos.php?eliminar=<?= $d['id_documento'] ?>"
                       onclick="return confirm('¿Eliminar este documento?')">Eliminar</a>
                </div>
            </article>
        <?php endwhile; ?>
    </section>
</main>
</body>
</html>
