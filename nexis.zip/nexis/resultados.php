<?php
include 'proteger.php';
include 'conexion.php';

$id = (int) ($_GET['id'] ?? 0);
$r = mysqli_query($conexion, "SELECT * FROM encuestas WHERE id_encuesta=$id");
$e = mysqli_fetch_assoc($r);

if (!$e) die('Encuesta no encontrada.');

$total = mysqli_fetch_row(mysqli_query($conexion,
    "SELECT COUNT(*) FROM respuestas_encuesta WHERE id_encuesta=$id"))[0];

$positivas = mysqli_fetch_row(mysqli_query($conexion,
    "SELECT COUNT(*) FROM respuestas r
     JOIN respuestas_encuesta re ON re.id_respuesta_encuesta=r.id_respuesta_encuesta
     WHERE re.id_encuesta=$id AND r.respuesta IN ('Muy satisfecho','Satisfecho')"))[0];

$porcentaje = $total ? round($positivas / $total * 100) : 0;
$otros = 100 - $porcentaje;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados - Hospital de Clínicas</title>
    <link rel="stylesheet" href="resultados.css">
</head>
<body>
<header>
    <a href="encuestas.php">← Volver</a>
    <h1>Resultados</h1>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main>
    <h2><?= htmlspecialchars($e['titulo']) ?></h2>
    <p>Resumen de las respuestas recibidas.</p>

    <section class="resumen">
        <div><b><?= $total ?></b><span>Respuestas</span></div>
        <div><b><?= $porcentaje ?>%</b><span>Resultado positivo</span></div>
        <div><b><?= $otros ?>%</b><span>Otros resultados</span></div>
    </section>

    <section class="tarjeta">
        <h3>Resultado general</h3>
        <div class="barra"><span style="width:<?= $porcentaje ?>%"></span></div>
        <p>El resultado positivo incluye “Muy satisfecho” y “Satisfecho”.</p>
    </section>
</main>
</body>
</html>
