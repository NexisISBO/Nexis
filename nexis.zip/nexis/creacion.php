<?php
include 'proteger.php';
include 'conexion.php';

if ($_SESSION['rol'] != 'administrador') die('No tiene permisos para crear usuarios.');

$mensaje = $error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = mysqli_real_escape_string($conexion, trim($_POST['usuario']));
    $clave = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $nombre = mysqli_real_escape_string($conexion, trim($_POST['nombre']));
    $correo = mysqli_real_escape_string($conexion, trim($_POST['correo']));
    $rol = mysqli_real_escape_string($conexion, $_POST['rol']);

    if (!$usuario || !$_POST['contrasena'] || !$nombre) {
        $error = 'Complete los campos obligatorios.';
    } else {
        $sql = "INSERT INTO usuarios (usuario, contraseña, nombre, correo, rol)
                VALUES ('$usuario', '$clave', '$nombre', '$correo', '$rol')";

        if (mysqli_query($conexion, $sql)) {
            $mensaje = 'Usuario creado correctamente.';
        } else {
            $error = 'No se pudo crear el usuario.';
        }
    }
}

$usuarios = mysqli_query($conexion, 'SELECT usuario,nombre,correo,rol FROM usuarios ORDER BY id_usuario DESC');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios - Hospital de Clínicas</title>
    <link rel="stylesheet" href="inicio.css">
</head>
<body>
<header>
    <a href="inicio.php">← Volver</a>
    <h1>Usuarios</h1>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main>
    <h2>Crear usuario</h2>

    <?php if ($mensaje): ?><p><?= htmlspecialchars($mensaje) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <form method="POST">
        <input name="usuario" placeholder="Usuario" required>
        <input name="contrasena" type="password" placeholder="Contraseña" required>
        <input name="nombre" placeholder="Nombre completo" required>
        <input name="correo" type="email" placeholder="Correo">
        <select name="rol">
            <option value="funcionario">Funcionario</option>
            <option value="administrador">Administrador</option>
        </select>
        <button>Crear usuario</button>
    </form>

    <h2>Usuarios registrados</h2>
    <table>
        <tr><th>Usuario</th><th>Nombre</th><th>Correo</th><th>Rol</th></tr>
        <?php while ($u = mysqli_fetch_assoc($usuarios)): ?>
            <tr>
                <td><?= htmlspecialchars($u['usuario']) ?></td>
                <td><?= htmlspecialchars($u['nombre']) ?></td>
                <td><?= htmlspecialchars($u['correo']) ?></td>
                <td><?= htmlspecialchars($u['rol']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</main>
</body>
</html>
