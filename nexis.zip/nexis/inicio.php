<?php
include 'proteger.php';
include 'conexion.php';

$documentos = mysqli_fetch_row(mysqli_query($conexion, 'SELECT COUNT(*) FROM documentos'))[0];
$ambulancias = mysqli_fetch_row(mysqli_query($conexion, 'SELECT COUNT(*) FROM ambulancias'))[0];
$encuestas = mysqli_fetch_row(mysqli_query($conexion, 'SELECT COUNT(*) FROM encuestas'))[0];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital de Clínicas</title>
    <link rel="stylesheet" href="inicio.css">
</head>
<body>
<header>
    <h1>Hospital de Clínicas</h1>
    <span><b>Usuario:</b> <?= htmlspecialchars($_SESSION['usuario']) ?></span>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main>
    <h2>Panel principal</h2>
    <p>Seleccione un módulo para continuar.</p>

    <section class="modulos">
        <a href="documentos.php">
            <b>Documentos</b>
            <span><?= $documentos ?> registrados</span>
        </a>
        <a href="ambulancias.php">
            <b>Ambulancias</b>
            <span><?= $ambulancias ?> registradas</span>
        </a>
        <a href="encuestas.php">
            <b>Encuestas</b>
            <span><?= $encuestas ?> creadas</span>
        </a>
    </section>

    <?php if ($_SESSION['rol'] == 'administrador'): ?>
        <p class="usuarios-link">
            <a href="creacion.php">Gestionar usuarios</a>
        </p>
    <?php endif; ?>
</main>

<footer>
    <div class="footer-contenido">
        <div class="marca">
            <img src="img/Nexis67.png" alt="Logo Nexis">
        </div>
        <div class="contacto">
            <h3>Contacto</h3>
            <p>Gmail: nexiserg0@gmail.com</p>
            <p>Teléfono: 098 123 456</p>
        </div>
    </div>
    <p class="derechos">© 2026 Nexis. Todos los derechos reservados.</p>
</footer>
</body>
</html>
