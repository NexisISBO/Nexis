<?php

$servidor = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "hospital_clinicas";

$conexion = mysqli_connect(
    $servidor,
    $usuario,
    $contrasena,
    $base_datos
);

if (!$conexion) {
    die("Error al conectar con la base de datos");
}

?>