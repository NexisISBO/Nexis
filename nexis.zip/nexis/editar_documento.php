<?php
include 'proteger.php';
include 'conexion.php';

$id = (int) ($_GET['id'] ?? 0);
$r = mysqli_query($conexion, "SELECT * FROM documentos WHERE id_documento=$id");
$d = mysqli_fetch_assoc($r);

if (!$d) die('Documento no encontrado.');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = mysqli_real_escape_string($conexion, trim($_POST['titulo']));
    $desc = mysqli_real_escape_string($conexion, trim($_POST['descripcion']));

    mysqli_query($conexion, "UPDATE documentos SET titulo='$titulo',descripcion='$desc' WHERE id_documento=$id");

    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] == 0) {
        $nombre = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['archivo']['name']));

        if (move_uploaded_file($_FILES['archivo']['tmp_name'], "documentos/$nombre")) {
            if (file_exists("documentos/{$d['archivo']}")) unlink("documentos/{$d['archivo']}");
            mysqli_query($conexion, "UPDATE documentos SET archivo='$nombre' WHERE id_documento=$id");
        }
    }

    header('Location: documentos.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar documento</title>
    <link rel="stylesheet" href="documentos.css">
</head>
<body>
<header>
    <a href="documentos.php">← Volver</a>
    <h1>Editar documento</h1>
</header>

<main>
    <section class="tarjeta formulario-editar">
        <h2>Editar documento</h2>
        <form method="POST" enctype="multipart/form-data">
            <label>Título</label>
            <input name="titulo" value="<?= htmlspecialchars($d['titulo']) ?>" required>

            <label>Descripción</label>
            <textarea name="descripcion"><?= htmlspecialchars($d['descripcion']) ?></textarea>

            <p>Archivo actual: <strong><?= htmlspecialchars($d['archivo']) ?></strong></p>
            <label>Reemplazar archivo</label>
            <input type="file" name="archivo">
            <button>Guardar cambios</button>
        </form>
    </section>
</main>
</body>
</html>
