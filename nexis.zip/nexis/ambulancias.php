<?php
include 'proteger.php';
include 'conexion.php';

$mensaje = $error = '';

if (isset($_GET['eliminar'])) {
    $id = (int) $_GET['eliminar'];
    mysqli_query($conexion, "DELETE FROM traslados WHERE id_ambulancia=$id");
    mysqli_query($conexion, "DELETE FROM ambulancias WHERE id_ambulancia=$id");
    header('Location: ambulancias.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $accion = $_POST['accion'];

    if ($accion == 'ambulancia') {
        $ident = mysqli_real_escape_string($conexion, trim($_POST['identificador']));
        $mat = mysqli_real_escape_string($conexion, trim($_POST['matricula']));
        $estado = mysqli_real_escape_string($conexion, $_POST['estado']);

        if (!$ident || !$mat) {
            $error = 'Complete los datos de la ambulancia.';
        } else {
            $sql = "INSERT INTO ambulancias(identificador,matricula,estado)
                    VALUES('$ident','$mat','$estado')";
            $mensaje = mysqli_query($conexion, $sql)
                ? 'Ambulancia registrada correctamente.'
                : 'No se pudo registrar la ambulancia.';
        }
    }

    if ($accion == 'traslado') {
        $id = (int) $_POST['id_ambulancia'];
        $pac = mysqli_real_escape_string($conexion, trim($_POST['paciente']));
        $con = mysqli_real_escape_string($conexion, trim($_POST['conductor']));
        $enf = mysqli_real_escape_string($conexion, trim($_POST['enfermero']));
        $ori = mysqli_real_escape_string($conexion, trim($_POST['origen']));
        $des = mysqli_real_escape_string($conexion, trim($_POST['destino']));
        $fecha = $_POST['fecha'];
        $hora = $_POST['hora'];
        $estado = mysqli_real_escape_string($conexion, $_POST['estado']);

        if (!$id || !$pac || !$con || !$ori || !$des || !$fecha || !$hora) {
            $error = 'Complete los campos obligatorios del traslado.';
        } else {
            $sql = "INSERT INTO traslados
                    (id_ambulancia,paciente,conductor,enfermero,origen,destino,fecha,hora,estado)
                    VALUES($id,'$pac','$con','$enf','$ori','$des','$fecha','$hora','$estado')";

            if (mysqli_query($conexion, $sql)) {
                mysqli_query($conexion, "UPDATE ambulancias SET estado='en traslado' WHERE id_ambulancia=$id");
                $mensaje = 'Traslado registrado correctamente.';
            } else $error = 'No se pudo registrar el traslado.';
        }
    }
}

$ambulancias = mysqli_query($conexion, 'SELECT * FROM ambulancias ORDER BY id_ambulancia DESC');
$disponibles = mysqli_query($conexion, "SELECT * FROM ambulancias WHERE estado!='mantenimiento'");
$traslados = mysqli_query($conexion,
    'SELECT t.*,a.identificador FROM traslados t
     JOIN ambulancias a ON a.id_ambulancia=t.id_ambulancia
     ORDER BY t.id_traslado DESC');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambulancias - Hospital de Clínicas</title>
    <link rel="stylesheet" href="ambulancias.css">
</head>
<body>
<header>
    <a href="inicio.php">← Volver</a>
    <h1>Ambulancias</h1>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main>
    <h2>Gestión de ambulancias</h2>
    <?php if ($mensaje): ?><p class="mensaje correcto"><?= htmlspecialchars($mensaje) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="mensaje error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <section class="tarjeta">
        <h3>Registrar ambulancia</h3>
        <form method="POST" class="formulario">
            <input type="hidden" name="accion" value="ambulancia">
            <div><label>Identificador</label><input name="identificador" placeholder="Ambulancia 01" required></div>
            <div><label>Matrícula</label><input name="matricula" required></div>
            <div><label>Estado</label><select name="estado">
                <option>disponible</option><option>en traslado</option><option>mantenimiento</option>
            </select></div>
            <button>Registrar ambulancia</button>
        </form>
    </section>

    <section class="tarjeta">
        <h3>Ambulancias registradas</h3>
        <div class="tabla-contenedor"><table>
            <tr><th>Identificador</th><th>Matrícula</th><th>Estado</th><th>Acción</th></tr>
            <?php while ($a = mysqli_fetch_assoc($ambulancias)): ?>
                <tr>
                    <td><?= htmlspecialchars($a['identificador']) ?></td>
                    <td><?= htmlspecialchars($a['matricula']) ?></td>
                    <td><?= htmlspecialchars($a['estado']) ?></td>
                    <td><a href="ambulancias.php?eliminar=<?= $a['id_ambulancia'] ?>"
                           onclick="return confirm('¿Eliminar esta ambulancia y sus traslados?')">Eliminar</a></td>
                </tr>
            <?php endwhile; ?>
        </table></div>
    </section>

    <section class="tarjeta">
        <h3>Registrar traslado</h3>
        <form method="POST" class="formulario">
            <input type="hidden" name="accion" value="traslado">
            <div><label>Ambulancia</label><select name="id_ambulancia" required>
                <option value="">Seleccione</option>
                <?php while ($a = mysqli_fetch_assoc($disponibles)): ?>
                    <option value="<?= $a['id_ambulancia'] ?>"><?= htmlspecialchars($a['identificador']) ?></option>
                <?php endwhile; ?>
            </select></div>
            <div><label>CI de Paciente</label><input name="paciente" required></div>
            <div><label>Conductor</label><input name="conductor" required></div>
            <div><label>CI de Enfermero/a</label><input name="enfermero"></div>
            <div><label>Origen</label><input name="origen" required></div>
            <div><label>Destino</label><input name="destino" required></div>
            <div><label>Fecha</label><input type="date" name="fecha" required></div>
            <div><label>Hora</label><input type="time" name="hora" required></div>
            <div><label>Estado</label><select name="estado">
                <option>pendiente</option><option>en curso</option><option>finalizado</option>
            </select></div>
            <button>Registrar traslado</button>
        </form>
    </section>

    <section class="tarjeta">
        <h3>Traslados registrados</h3>
        <div class="tabla-contenedor"><table>
            <tr><th>Ambulancia</th><th>Paciente</th><th>Origen</th><th>Destino</th><th>Fecha</th><th>Estado</th></tr>
            <?php while ($t = mysqli_fetch_assoc($traslados)): ?>
                <tr>
                    <td><?= htmlspecialchars($t['identificador']) ?></td>
                    <td><?= htmlspecialchars($t['paciente']) ?></td>
                    <td><?= htmlspecialchars($t['origen']) ?></td>
                    <td><?= htmlspecialchars($t['destino']) ?></td>
                    <td><?= $t['fecha'] ?></td>
                    <td><?= htmlspecialchars($t['estado']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table></div>
    </section>
</main>
</body>
</html>
