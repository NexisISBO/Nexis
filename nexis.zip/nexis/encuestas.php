<?php
include 'proteger.php';
include 'conexion.php';

$mensaje = $error = '';

if (isset($_GET['eliminar'])) {
    $id = (int) $_GET['eliminar'];
    mysqli_query($conexion, "DELETE r FROM respuestas r JOIN respuestas_encuesta re ON re.id_respuesta_encuesta=r.id_respuesta_encuesta WHERE re.id_encuesta=$id");
    mysqli_query($conexion, "DELETE FROM respuestas_encuesta WHERE id_encuesta=$id");
    mysqli_query($conexion, "DELETE FROM preguntas WHERE id_encuesta=$id");
    mysqli_query($conexion, "DELETE FROM encuestas WHERE id_encuesta=$id");
    header('Location: encuestas.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = mysqli_real_escape_string($conexion, trim($_POST['titulo']));
    $desc = mysqli_real_escape_string($conexion, trim($_POST['descripcion']));
    $preg = mysqli_real_escape_string($conexion, trim($_POST['pregunta']));

    if (!$titulo || !$preg) {
        $error = 'Complete el título y la pregunta.';
    } else {
        $sql = "INSERT INTO encuestas(titulo,descripcion,id_usuario)
                VALUES('$titulo','$desc'," . (int)$_SESSION['id_usuario'] . ')';

        if (mysqli_query($conexion, $sql)) {
            $id = mysqli_insert_id($conexion);
            mysqli_query($conexion, "INSERT INTO preguntas(id_encuesta,pregunta,tipo,orden) VALUES($id,'$preg','opcion',1)");
            $mensaje = 'Encuesta creada correctamente.';
        } else $error = 'No se pudo crear la encuesta.';
    }
}

$encuestas = mysqli_query($conexion, 'SELECT * FROM encuestas ORDER BY id_encuesta DESC');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encuestas - Hospital de Clínicas</title>
    <link rel="stylesheet" href="encuestas.css">
</head>
<body>
<header class="encabezado">
    <a href="inicio.php">← Volver</a>
    <h1>Encuestas</h1>
    <a href="cerrar_sesion.php">Cerrar sesión</a>
</header>

<main class="contenedor">
    <section class="cabecera-pagina">
        <h2>Encuestas</h2>
        <p>Creá encuestas para conocer la opinión de los pacientes.</p>
    </section>

    <?php if ($mensaje): ?><div class="mensaje correcto"><?= htmlspecialchars($mensaje) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="mensaje error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <section class="tarjeta crear-encuesta">
        <h3>Crear encuesta</h3>
        <form method="POST">
            <label>Título</label>
            <input name="titulo" placeholder="Ej.: Encuesta de satisfacción" required>
            <label>Descripción</label>
            <textarea name="descripcion" placeholder="Objetivo de la encuesta"></textarea>
            <label>Pregunta</label>
            <input name="pregunta" placeholder="¿Qué tan satisfecho está con la atención?" required>
            <button>Crear encuesta</button>
        </form>
    </section>

    <section class="lista-encuestas">
        <h3>Encuestas creadas</h3>

        <?php if (mysqli_num_rows($encuestas) == 0): ?>
            <div class="tarjeta vacio">No hay encuestas creadas todavía.</div>
        <?php endif; ?>

        <?php while ($e = mysqli_fetch_assoc($encuestas)): ?>
            <?php $id = $e['id_encuesta']; $url = "http://localhost/nexis/encuesta_publica.php?id=$id"; ?>
            <article class="tarjeta encuesta">
                <div class="encuesta-info">
                    <span class="estado">Activa</span>
                    <h3><?= htmlspecialchars($e['titulo']) ?></h3>
                    <p><?= htmlspecialchars($e['descripcion']) ?></p>
                    <div class="acciones">
                        <a class="boton-secundario" href="encuesta_publica.php?id=<?= $id ?>" target="_blank">Abrir encuesta</a>
                        <a class="boton-secundario" href="resultados.php?id=<?= $id ?>">Ver resultados</a>
                        <a class="boton-eliminar" href="encuestas.php?eliminar=<?= $id ?>"
                           onclick="return confirm('¿Eliminar esta encuesta?')">Eliminar</a>
                    </div>
                </div>
                <div class="qr">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=<?= urlencode($url) ?>" alt="Código QR">
                    <small>Escaneá para responder</small>
                </div>
            </article>
        <?php endwhile; ?>
    </section>
</main>
</body>
</html>
