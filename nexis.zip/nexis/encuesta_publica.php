<?php
include 'conexion.php';

$id = (int) ($_GET['id'] ?? 0);
$r = mysqli_query($conexion, "SELECT * FROM encuestas WHERE id_encuesta=$id AND estado='activa'");
$e = mysqli_fetch_assoc($r);

if (!$e) die('Encuesta no encontrada.');

$mensaje = $error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (mysqli_query($conexion, "INSERT INTO respuestas_encuesta(id_encuesta) VALUES($id)")) {
        $respuesta_id = mysqli_insert_id($conexion);
        $preguntas = mysqli_query($conexion, "SELECT id_pregunta FROM preguntas WHERE id_encuesta=$id ORDER BY orden,id_pregunta");

        while ($p = mysqli_fetch_assoc($preguntas)) {
            $campo = 'pregunta_' . $p['id_pregunta'];
            $resp = mysqli_real_escape_string($conexion, trim($_POST[$campo] ?? ''));

            if ($resp) {
                mysqli_query($conexion, "INSERT INTO respuestas(id_respuesta_encuesta,id_pregunta,respuesta) VALUES($respuesta_id,{$p['id_pregunta']},'$resp')");
            }
        }
        $mensaje = 'Gracias por completar la encuesta.';
    } else $error = 'No se pudieron guardar las respuestas.';
}

$preguntas = mysqli_query($conexion, "SELECT * FROM preguntas WHERE id_encuesta=$id ORDER BY orden,id_pregunta");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($e['titulo']) ?></title>
    <link rel="stylesheet" href="encuestas.css">
</head>
<body class="pagina-publica">
<main class="encuesta-publica">
    <div class="encuesta-logo">Hospital de Clínicas</div>

    <section class="tarjeta formulario-publico">
        <div class="intro">
            <h1><?= htmlspecialchars($e['titulo']) ?></h1>
            <p><?= htmlspecialchars($e['descripcion']) ?></p>
        </div>

        <?php if ($mensaje): ?>
            <div class="mensaje correcto"><?= htmlspecialchars($mensaje) ?></div>
        <?php elseif ($error): ?>
            <div class="mensaje error"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <form method="POST">
                <?php while ($p = mysqli_fetch_assoc($preguntas)): ?>
                    <div class="pregunta">
                        <label><?= htmlspecialchars($p['pregunta']) ?></label>
                        <select name="pregunta_<?= $p['id_pregunta'] ?>" required>
                            <option value="">Seleccioná una opción</option>
                            <option>Muy satisfecho</option>
                            <option>Satisfecho</option>
                            <option>Regular</option>
                            <option>Insatisfecho</option>
                            <option>Muy insatisfecho</option>
                        </select>
                    </div>
                <?php endwhile; ?>
                <button>Enviar respuestas</button>
            </form>
        <?php endif; ?>
    </section>

    <p class="pie-publico">Hospital de Clínicas · Nexis</p>
</main>
</body>
</html>
