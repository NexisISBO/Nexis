<?php
session_start();
include("conexion.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = $_POST["usuario"];
    $contrasena = $_POST["contrasena"];

    $sql = "SELECT * FROM usuarios 
            WHERE usuario='$usuario' 
            AND contraseña='$contrasena'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) == 1) {

        $datos = mysqli_fetch_assoc($resultado);

        $_SESSION["usuario"] = $datos["usuario"];
        $_SESSION["rol"] = $datos["rol"];

        header("Location: inicio.php");
        exit();

    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hospital de Clínicas - Ingreso</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>

<main class="login">

    <h1>Hospital de Clínicas</h1>
    <p>Acceso para funcionarios</p>

    <form method="POST">

        <label>Usuario</label>
        <input type="text" name="usuario" placeholder="Ingrese su usuario" required>

        <label>Contraseña</label>
        <input type="password" name="contrasena" placeholder="Ingrese su contraseña" required>

        <button type="submit" class="boton">Ingresar</button>

    </form>

    <?php
    if ($error != "") {
        echo "<p>$error</p>";
    }
    ?>

</main>

</body>
</html>