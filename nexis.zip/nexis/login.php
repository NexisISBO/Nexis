<?php
session_start();
include 'conexion.php';

if (isset($_SESSION['id_usuario'])) {
    header('Location: inicio.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = mysqli_real_escape_string($conexion, trim($_POST['usuario']));
    $clave = $_POST['contrasena'];

    $sql = "SELECT * FROM usuarios WHERE usuario='$usuario' LIMIT 1";
    $resultado = mysqli_query($conexion, $sql);
    $u = mysqli_fetch_assoc($resultado);

    if ($u && password_verify($clave, $u['contraseña'])) {
        $_SESSION['id_usuario'] = $u['id_usuario'];
        $_SESSION['usuario'] = $u['usuario'];
        $_SESSION['rol'] = $u['rol'];
        header('Location: inicio.php');
        exit;
    }

    $error = 'Usuario o contraseña incorrectos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital de Clínicas - Ingreso</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <main class="login">
        <h1>Hospital de Clínicas</h1>
        <p>Acceso para funcionarios</p>

        <form method="POST">
            <label>Usuario</label>
            <input name="usuario" required>

            <label>Contraseña</label>
            <input name="contrasena" type="password" required>

            <button>Ingresar</button>
        </form>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
    </main>
</body>
</html>
